fetch('data/story.json')
  .then(res => res.json())
  .then(data => {
    let current = 0;
    const storyDiv = document.getElementById('story');
    const choicesDiv = document.getElementById('choices');

    function showScene(index) {
      const scene = data[index];
      storyDiv.innerText = scene.text;
      choicesDiv.innerHTML = '';
      scene.choices.forEach(choice => {
        const btn = document.createElement('button');
        btn.innerText = choice.text;
        btn.onclick = () => showScene(choice.next);
        choicesDiv.appendChild(btn);
      });
    }

    showScene(current);
  });